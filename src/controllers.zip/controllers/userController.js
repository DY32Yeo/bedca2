const userModel = require("../models/userModel.js");
const completionModel = require("../models/completionModel.js");
const userpetModel = require("../models/userpetModel.js");
const inventoryModel = require("../models/inventoryModel.js");

module.exports.checkAllUser = (req, res, next) =>
{   
    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error checkAllUser:", error);
            res.status(500).json(error);
        } 
        else {
            // store all the username in an array
            nameStore = results;
            next();
        }
    }

    userModel.selectAll(callback);
}

// module.exports.createNewUser = (req, res, next) =>
// {
//     if(req.body.username == undefined)
//     {
//         return res.status(400).json({
//             message: "Error: username is missing"
//         });
//     }

//     // it will loop thru the array of username and check for duplicate username if it exists the error will be triggered
//     for (let i = 0; i < nameStore.length; i++) {
//         if(req.body.username == nameStore[i].username)
//         {
//             return res.status(409).json({
//                 message: "Error: username is already associated with another user"
//             });
//         } 
//     }

//     const data = {
//         username: req.body.username,
//         points: 0
//     }

//     const callback = (error, results, fields) => {
//         if (error) {
//             console.error("Error createNewUser:", error);
//             res.status(500).json(error);
//         } else {
//             res.status(201).json({
//                 user_id: results.insertId,
//                 username: data.username,
//                 points: data.points
//             });
//         }
//     }

//     userModel.insertSingle(data, callback);
// }

module.exports.readAllUser = (req, res, next) =>
{
    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readAllUser:", error);
            res.status(500).json(error);
        } 
        else res.status(200).json(results);
    }

    userModel.selectUser(callback);
}

module.exports.readUserById = (req, res, next) =>
{
    const loggedInUserId = res.locals.userId;
    const targetUserId = parseInt(req.params.user_id);

    if (loggedInUserId !== targetUserId) {
        return res.status(403).json({
            message: "Forbidden: You can only view your own profile"
        });
    }

    const data = {
        user_id: req.params.user_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readUserById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "user_id does not exist"
                });
            }
            else res.status(200).json(results[0]);
        }
    }

    userModel.selectById(data, callback);
}

module.exports.updateUserById = (req, res, next) =>
{
    if(req.body.username == undefined)
    {
        return res.status(400).json({
            message: "Error: username is missing"
        });
    }

    const loggedInUserId = res.locals.userId;
    const targetUserId = parseInt(req.params.user_id);

    if (loggedInUserId !== targetUserId) {
        return res.status(403).json({
            message: "Forbidden: You can only update your own profile"
        });
    }

    // loops thru the array of username to check for duplicated username, if it exists the error will be triggered
    for (let i = 0; i < nameStore.length; i++) {
        if(req.body.username == nameStore[i].username)
        {
            return res.status(409).json({
                message: "Error: username is already associated with another user"
            });
        } 
    }

    const data = {
        user_id: req.params.user_id,
        username: req.body.username,
        // points: req.body.points
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error updateUserById:", error);
            res.status(500).json(error);
        } else {
            if(results.affectedRows == 0) 
            {
                res.status(404).json({
                    message: "user_id does not exist"
                });
            }
            else res.status(200).json({
                user_id: data.user_id,
                username: data.username,
                // points: data.points
            });
        }
    }

    userModel.updateById(data, callback);
}

module.exports.checkUserById = (req, res, next) =>
{

    const data = {
        user_id: res.locals.userId
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error checkUserById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                return res.status(404).json({
                    message: "user_id does not exist"
                });
            }
        }
        req.user = results[0];
        next();

    }

    userModel.selectById(data, callback);
}

module.exports.getLeaderboard = (req, res, next) =>
{

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error getLeaderboard:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "No user with pet found."
                });
            }
            else res.status(200).json(results);
        }
    }

    userModel.selectRank(callback);
}

module.exports.login = (req, res, next) => {
    try { 
        const requiredFields = ['username', 'password'];

        for (const field of requiredFields) {
            if (req.body[field] === undefined || req.body[field] === "") {
                res.status(400).json({ message: `${field} is undefined or empty` });
                return;
            }
        };

        const data = {
            username: req.body.username,
            password: res.locals.hash    
        };

        const callback = (error, results) => {
            if(error){
                console.error("Error login callback: ", error);
                res.status(500).json(error);
            } else {
                if(results.length == 0){
                    res.status(404).json({message: "User not found"}); 
                } else {
                    res.locals.userId = results[0].user_id
                    res.locals.hash = results[0].password
                    next();
                }
            }
        };

        userModel.login(data, callback);

    } catch (error) {
        console.error("Error login: ", error);
        res.status(500).json(error);
    }
}

module.exports.checkUsernameOrEmailExist = (req, res, next) => {
    try {
        const requiredFields = ['username', 'email'];

        for (const field of requiredFields) {
            if (req.body[field] === undefined || req.body[field] === "") {
                res.status(400).json({ message: `${field} is undefined or empty` });
                return;
            }
        };
    
        const data = {
            email: req.body.email,
            username: req.body.username
        };

        const callback = (error, results) => {
            if(error){
                console.error("Error readUserByEmailAndUsername callback: ", error);
                res.status(500).json(error);
            } else {
                if(results.length != 0){
                    res.status(409).json({message: "Username or email already exists"});
                } else {
                    next();
                }
            }
        };

        userModel.readUserByEmailAndUsername(data, callback);

    } catch (error) {
        console.error("Error readUserByEmailAndUsername: ", error);
        res.status(500).json(error);
    }

}

module.exports.register = (req, res, next) => {
        try { 
            const data = {
                email: req.body.email,
                username: req.body.username,
                password: res.locals.hash
            };
    
            const callback = (error, results) => {
                if(error){
                    console.error("Error register callback: ", error);
                    res.status(500).json(error);
                } else {
                    res.locals.userId = results.insertId;
                    next();
                }
            };
    
            userModel.register(data, callback);
    
        } catch (error) {
            console.error("Error register: ", error);
            res.status(500).json(error);
        }
}

module.exports.deleteUserById = (req, res, next) =>
{
    const loggedInUserId = res.locals.userId;
    const targetUserId = parseInt(req.params.user_id);

    // Check if user is deleting their own account 
    if (loggedInUserId !== targetUserId) {
        return res.status(403).json({
            message: "Forbidden: You can only delete your own account"
        });
    }
    
    const data = {
        user_id: req.params.user_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error deleteUserById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "user_id does not exist"
                });
            }
            else res.status(204).send();
        }
    }

    userModel.deleteById(data, callback);
}

module.exports.getUserInfo = (req, res, next) =>
{
    const data = {
        user_id: res.locals.userId
    };

    // 1) User basic info
    userModel.selectProfileById(data, (error, userResults) =>
    {
        if (error)
        {
            console.error("Error selectProfileById:", error);
            return res.status(500).json(error);
        }

        if (userResults.length == 0)
        {
            return res.status(404).json({ message: "user_id does not exist" });
        }

        const user = userResults[0];

        // 2) Completion count
        completionModel.countTotalByUserId(data, (error, completionResults) =>
        {
            if (error)
            {
                console.error("Error countTotalByUserId:", error);
                return res.status(500).json(error);
            }

            const completion_count = completionResults[0].completion_count;

            // 3) Pet details
            userpetModel.selectUserPetDetailsByUserId(data, (error, petResults) =>
            {
                if (error)
                {
                    console.error("Error selectUserPetDetailsByUserId:", error);
                    return res.status(500).json(error);
                }

                // 4) Inventory
                inventoryModel.selectValidUserInventory(data, (error, inventoryResults) =>
                {
                    if (error)
                    {
                        console.error("Error selectValidUserInventory:", error);
                        return res.status(500).json(error);
                    }

                    return res.status(200).json({
                        user: user,
                        completion_count: completion_count,
                        pet: petResults,        
                        inventory: inventoryResults
                    });
                });
            });
        });
    });
}
