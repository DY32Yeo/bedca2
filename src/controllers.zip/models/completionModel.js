const pool = require('../services/db');

module.exports.insertCompletion = (data, callback) =>
{
    const SQLSTATMENT = `
    INSERT INTO UserCompletion (challenge_id, user_id, details)
    VALUES (?, ?, ?);
    `;
    const VALUES = [data.challenge_id, data.user_id, data.details];

    pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.getAttemptById = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT user_id, details
    FROM UserCompletion
    WHERE challenge_id = ?;
    `;
    const VALUES = [data.challenge_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.getCompletionById = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT 
        challenge_id,
        COUNT(*) as completion_count
    FROM UserCompletion
    WHERE user_id = ?
    GROUP BY challenge_id;
    `;
    const VALUES = [data.user_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.countTotalByUserId = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT COUNT(*) AS completion_count
    FROM UserCompletion
    WHERE user_id = ?;
    `;
    const VALUES = [data.user_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}
